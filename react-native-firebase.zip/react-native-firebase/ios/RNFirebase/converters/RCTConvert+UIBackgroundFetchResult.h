#import <React/RCTConvert.h>

@interface RCTConvert (UIBackgroundFetchResult)

@end
