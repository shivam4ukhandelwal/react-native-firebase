#ifndef RNFirebase_h
#define RNFirebase_h
#import <Foundation/Foundation.h>

#import <React/RCTEventEmitter.h>
#import <React/RCTBridgeModule.h>

@interface RNFirebase : RCTEventEmitter <RCTBridgeModule> {
}

@end

#endif
