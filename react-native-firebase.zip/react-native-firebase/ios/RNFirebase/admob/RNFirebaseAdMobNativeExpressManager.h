#import <React/RCTViewManager.h>

@interface RNFirebaseAdMobNativeExpressManager : RCTViewManager

@end