#import <React/RCTViewManager.h>

@interface RNFirebaseAdMobBannerManager : RCTViewManager

@end